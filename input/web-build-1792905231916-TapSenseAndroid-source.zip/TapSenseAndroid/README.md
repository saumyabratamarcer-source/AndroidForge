# TapSense Android — prototype source

This is an Android Studio starter project for a floating, text-triggered tap assistant.

## What this prototype does
- Lets you save an ordered list of target phrases (one per line).
- Uses Android Accessibility events to look for the **next exact phrase** in the active app's accessibility tree.
- Provides a floating `TS • OFF/ON` control bubble.
- It does not tap arbitrary coordinates or repeat taps while the target is absent.

## Important limitations
- This is **source code, not a prebuilt APK**. It must be compiled and tested with Android Studio/Gradle.
- The first prototype uses Android's accessibility tree, not OCR over every pixel. Apps that do not expose their text to Accessibility may not be detected. Screenshot OCR/MediaProjection is a separate feature and is not implemented here.
- This is an early prototype; review and test before relying on it. Accessibility services are powerful and should be enabled only for an app you trust.
- Android may restrict background behavior. Keep the floating control visible and stop it when done.
- It deliberately does not auto-start hidden or run without a visible control.

## Build
1. Install Android Studio on a Windows PC.
2. Open this folder as a project.
3. Allow Gradle sync/downloads.
4. Connect the Android phone with USB debugging enabled, or use Build > Build APK(s).
5. Install the generated debug APK on your phone.

## On the phone
1. Open TapSense and enter one phrase per line, e.g. `Skip`, `Continue`, `Next`.
2. Save the sequence.
3. Enable **TapSense text-triggered tapping** under Android Accessibility settings.
4. Grant overlay permission.
5. Return to TapSense and start the floating control.
6. Open the target app and tap the bubble to arm. It waits for the first phrase and advances through the sequence only after successful activation.

This prototype should be tested on non-sensitive screens first. Some apps may block or not expose text to Accessibility.
