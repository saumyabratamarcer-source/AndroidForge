package com.tapsense.autoclicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class TapSenseAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var lastTapAt = 0L
    private var lastTarget = ""
    private var nextIndex = 0
    private var armed = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!armed || event == null) return
        if (event.eventType !in setOf(
                AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,
                AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
                AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED,
                AccessibilityEvent.TYPE_WINDOWS_CHANGED
            )) return
        // Debounce content-change bursts. The current UI is scanned only for the next
        // explicitly recorded target; it never taps arbitrary elements.
        handler.removeCallbacks(scanRunnable)
        handler.postDelayed(scanRunnable, 350)
    }

    private val scanRunnable = Runnable { scanForNextTarget() }

    private fun scanForNextTarget() {
        if (!armed) return
        val prefs = getSharedPreferences("tapsense", MODE_PRIVATE)
        val targets = prefs.getString("targets", "").orEmpty()
            .lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (targets.isEmpty()) { disarm(); return }
        if (nextIndex >= targets.size) { disarm(); return }

        val wanted = targets[nextIndex]
        val root = rootInActiveWindow ?: return
        val nodes = try { root.findAccessibilityNodeInfosByText(wanted) } catch (_: Exception) { emptyList() }
        val match = nodes.firstOrNull { node ->
            val text = node.text?.toString()?.trim()
            val desc = node.contentDescription?.toString()?.trim()
            (text.equals(wanted, true) || desc.equals(wanted, true)) &&
                node.isVisibleToUser && (node.isClickable || node.parent?.isClickable == true)
        }
        if (match != null) {
            val now = System.currentTimeMillis()
            if (now - lastTapAt > 1200 || lastTarget != wanted) {
                val clicked = clickNodeOrParent(match)
                if (clicked) {
                    lastTapAt = now
                    lastTarget = wanted
                    nextIndex += 1
                    if (nextIndex >= targets.size) disarm()
                }
            }
        }
        nodes.forEach { if (it !== match) it.recycle() }
        root.recycle()
    }

    private fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        repeat(5) {
            val candidate = current ?: return false
            if (candidate.isClickable && candidate.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            current = candidate.parent
        }
        val bounds = android.graphics.Rect()
        node.getBoundsInScreen(bounds)
        if (bounds.isEmpty) return false
        val path = Path().apply { moveTo(bounds.exactCenterX(), bounds.exactCenterY()) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 80))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    fun arm() {
        nextIndex = 0
        lastTapAt = 0
        lastTarget = ""
        armed = true
    }

    fun disarm() {
        armed = false
        handler.removeCallbacks(scanRunnable)
    }

    override fun onInterrupt() { disarm() }

    companion object {
        @Volatile var instance: TapSenseAccessibilityService? = null
            private set
        @Volatile var overlayArmed: Boolean = false
    }
}
