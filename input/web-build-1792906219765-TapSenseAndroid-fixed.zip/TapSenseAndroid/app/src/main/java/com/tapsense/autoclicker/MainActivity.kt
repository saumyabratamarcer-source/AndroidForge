package com.tapsense.autoclicker

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var targets: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (resources.displayMetrics.density * 20).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(0xFF101411.toInt())
        }
        val title = TextView(this).apply {
            text = "TAPSENSE"
            textSize = 26f
            setTextColor(0xFFD8FF62.toInt())
        }
        val intro = TextView(this).apply {
            text = "Text-triggered tapping • no blind tapping"
            textSize = 15f
            setTextColor(0xFFE3E8E2.toInt())
            setPadding(0, pad / 2, 0, pad)
        }
        targets = EditText(this).apply {
            hint = "One target per line, in order\\nSkip\\nContinue\\nNext"
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF929A91.toInt())
            setSingleLine(false)
            minLines = 4
            gravity = Gravity.TOP
            setPadding(pad / 2, pad / 2, pad / 2, pad / 2)
            setBackgroundColor(0xFF202820.toInt())
        }
        val save = Button(this).apply {
            text = "Save target sequence"
            setOnClickListener {
                val list = targets.text.toString().lines().map { it.trim() }.filter { it.isNotEmpty() }
                getSharedPreferences("tapsense", MODE_PRIVATE).edit()
                    .putString("targets", list.joinToString("\n")).apply()
                status.text = "Saved ${list.size} target(s). Enable Accessibility below."
            }
        }
        val accessibility = Button(this).apply {
            text = "Enable Accessibility Service"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val overlay = Button(this).apply {
            text = "Allow floating control"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else {
                    startService(Intent(this@MainActivity, FloatingControlService::class.java))
                    status.text = "Floating control started. Use its button to arm/disarm."
                }
            }
        }
        status = TextView(this).apply {
            text = "Ready. Save targets, enable Accessibility, then allow overlay."
            setTextColor(0xFFD8FF62.toInt())
            setPadding(0, pad, 0, pad)
        }
        listOf(title, intro, targets, save, accessibility, overlay, status).forEach {
            layout.addView(it, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = pad / 3
            })
        }
        setContentView(ScrollView(this).apply { addView(layout) })
        targets.setText(getSharedPreferences("tapsense", MODE_PRIVATE).getString("targets", "Skip\nContinue\nNext"))
    }
}
