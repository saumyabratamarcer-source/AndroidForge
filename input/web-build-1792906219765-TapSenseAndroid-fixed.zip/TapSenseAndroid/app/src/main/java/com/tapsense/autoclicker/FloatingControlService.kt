package com.tapsense.autoclicker

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.Toast

class FloatingControlService : Service() {
    private var windowManager: WindowManager? = null
    private var button: Button? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (button != null) return START_STICKY
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        button = Button(this).apply {
            text = "TS • OFF"
            setOnClickListener {
                val service = TapSenseAccessibilityService.instance
                if (TapSenseAccessibilityService.overlayArmed) {
                    TapSenseAccessibilityService.overlayArmed = false
                    service?.disarm()
                    text = "TS • OFF"
                    Toast.makeText(this@FloatingControlService, "TapSense paused", Toast.LENGTH_SHORT).show()
                } else if (service != null) {
                    TapSenseAccessibilityService.overlayArmed = true
                    service.arm()
                    text = "TS • ON"
                    Toast.makeText(this@FloatingControlService, "Waiting for recorded text", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this@FloatingControlService, "Enable TapSense Accessibility first", Toast.LENGTH_LONG).show()
                }
            }
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 16; y = 180 }
        windowManager?.addView(button, params)
        return START_STICKY
    }

    override fun onDestroy() {
        button?.let {
            try { windowManager?.removeView(it) } catch (_: Exception) { }
        }
        button = null
        windowManager = null
        TapSenseAccessibilityService.instance?.disarm()
        TapSenseAccessibilityService.overlayArmed = false
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
