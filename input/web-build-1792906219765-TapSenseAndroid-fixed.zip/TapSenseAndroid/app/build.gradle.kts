plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    // Keep Java and Kotlin bytecode targets consistent; AndroidForge uses Gradle 8.9.
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    namespace = "com.tapsense.autoclicker"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.tapsense.autoclicker"
        minSdk = 26
        // Accessibility/overlay app; SDK 35 remains compatible with Android 13.
        targetSdk = 32
        versionCode = 1
        versionName = "0.1.0"
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
